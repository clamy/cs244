"CS244 Assignment #1: Parking Lot"
